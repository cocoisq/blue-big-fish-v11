# 藍色大肥魚 V11 Android Game
A standalone Android wrapper for the V11 tap game.
- Original V11 character art and embedded sound retained.
- App tap animation and five one-second phrases.
- Shared daily click counter for app and home-screen widget; reset is checked on each read/tap.
- Widget uses a navy border; Android launcher widgets have RemoteViews animation limitations.
Build: `gradle assembleDebug` (JDK 17, Gradle 8.9, Android SDK 35).
