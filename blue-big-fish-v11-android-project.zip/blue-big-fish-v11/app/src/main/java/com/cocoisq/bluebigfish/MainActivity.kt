package com.cocoisq.bluebigfish
import android.app.*
import android.appwidget.AppWidgetManager
import android.content.*
import android.os.Bundle
import android.webkit.*
import android.widget.RemoteViews
import android.app.Activity
import java.text.SimpleDateFormat
import java.util.*

object DailyCount {
 private const val PREF="blue_fish_daily"
 private fun today()=SimpleDateFormat("yyyy-MM-dd", Locale.TAIWAN).format(Date())
 fun count(c:Context):Int { val p=c.getSharedPreferences(PREF,0); if(p.getString("day","")!=today()) p.edit().putString("day",today()).putInt("count",0).apply(); return p.getInt("count",0) }
 fun tap(c:Context):Int { val n=count(c)+1; c.getSharedPreferences(PREF,0).edit().putInt("count",n).apply(); update(c); return n }
 fun update(c:Context) { val m=AppWidgetManager.getInstance(c); val ids=m.getAppWidgetIds(android.content.ComponentName(c,FishWidget::class.java)); ids.forEach { FishWidget.render(c,m,it) } }
}
class MainActivity:Activity() {
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState)
  val w=WebView(this); w.settings.javaScriptEnabled=true; w.settings.domStorageEnabled=true
  w.addJavascriptInterface(object { @JavascriptInterface fun getCount()=DailyCount.count(this@MainActivity)
   @JavascriptInterface fun onTap()=DailyCount.tap(this@MainActivity) },"AndroidBridge")
  setContentView(w); w.loadUrl("file:///android_asset/index.html")
 }
}
class FishWidget:BroadcastReceiver() {
 override fun onReceive(c:Context, i:Intent) { if(i.action=="com.cocoisq.bluebigfish.TAP") { DailyCount.tap(c); c.getSharedPreferences("blue_fish_daily",0).edit().putString("phrase",listOf("好了","不要點了","幹嘛","啊","哦鯨鯨").random()).apply() }; val m=AppWidgetManager.getInstance(c); m.getAppWidgetIds(ComponentName(c,FishWidget::class.java)).forEach { render(c,m,it) } }
 companion object {
 fun render(c:Context,m:AppWidgetManager,id:Int) { val v=RemoteViews(c.packageName,R.layout.widget); val p=c.getSharedPreferences("blue_fish_daily",0); v.setTextViewText(R.id.widget_count,"被戳了 ${DailyCount.count(c)} 次"); v.setTextViewText(R.id.widget_phrase,p.getString("phrase","") ?: "")
  val it=Intent(c,FishWidget::class.java).setAction("com.cocoisq.bluebigfish.TAP"); val pi=PendingIntent.getBroadcast(c, id,it,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); v.setOnClickPendingIntent(R.id.widget_maid,pi); m.updateAppWidget(id,v)
 }
 }
}
